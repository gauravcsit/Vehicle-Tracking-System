﻿using System.Configuration;

namespace TrackingSystem.Services
{

    public class FileSettingService : ISettingService
    {
        public string GetTSConnectionString()
        {
            //read from web.config
            string connection = ConfigurationManager.ConnectionStrings["DBTrackingConnection"].ConnectionString;
            return connection;
        }
    }
}
