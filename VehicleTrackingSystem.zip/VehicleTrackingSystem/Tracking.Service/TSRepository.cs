﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using TrackingSystem.Entities;
using TrackingSystem.Repo;

namespace TrackingSystem.Services
{
    public class TSRepository : ITSRepository
    {
        private readonly ISettingService _settings;
        private readonly IContext _context;

        public TSRepository(ISettingService settings, IContext context)
        {
            _settings = settings;
            _context = context;

            _context.SetConnectionString(_settings.GetTSConnectionString());

        }

        public bool RecordVehicleTracking(VehicleTracking vehicleTracking, int shardMapId)
        {
            DateTime recordDateTime = GetDateTimeFromDateAndTime(vehicleTracking.RecordAtDate, vehicleTracking.RecordAtTime);

            SqlParameter[] parameter = new SqlParameter[9];

            parameter[0] = new SqlParameter("@RawDataRecived", vehicleTracking.RawDataRecived);
            parameter[1] = new SqlParameter("@VehicleId", vehicleTracking.VehicleId);
            parameter[2] = new SqlParameter("@RecordAtDate", recordDateTime.Date);
            parameter[3] = new SqlParameter("@RecordAtTime", recordDateTime.TimeOfDay);
            parameter[4] = new SqlParameter("@Latitude", vehicleTracking.Latitude);
            parameter[5] = new SqlParameter("@LatitudeCompassDirection", vehicleTracking.LatitudeCompassDirection);
            parameter[6] = new SqlParameter("@Longitude", vehicleTracking.Longitude);
            parameter[7] = new SqlParameter("@LongitudeCompassDirection", vehicleTracking.LongitudeCompassDirection);
            parameter[8] = new SqlParameter("@Speed", vehicleTracking.Speed);

            if (shardMapId == 2)
            {
                _context.ExecuteCommand("RecordVehicleTracking_2", parameter);
            }
            else
            {
                _context.ExecuteCommand("RecordVehicleTracking_1", parameter);
            }

            return true;
        }

        private DateTime GetDateTimeFromDateAndTime(string recordAtDate, string recordAtTime)
        {
            DateTime d = DateTime.ParseExact(recordAtDate+" "+recordAtTime, "ddMMyy HHmmss", System.Globalization.CultureInfo.InvariantCulture);
            return d;
        }

        /// <summary>
        /// Current Location of Vehicle
        /// </summary>
        /// <param name="vehicleMaster"></param>
        /// <returns></returns>
        public VehicleTracking GetCurrentLocationByVehicle(string Chip_SN)
        {
            SqlParameter[] parameter = new SqlParameter[1];

            parameter[0] = new SqlParameter("@chip_SN", Chip_SN);

            var dt = _context.ExecuteQuery("GetCurrentLocationByVehicle", parameter);

            VehicleTracking tracking = null;
            if (dt != null && dt.Rows.Count > 0)
            {
                tracking = new VehicleTracking();
                tracking.RawDataRecived = Convert.ToString(dt.Rows[0]["RawDataRecived"]);
                tracking.VehicleId = Convert.ToInt32(dt.Rows[0]["VehicleId"]);
                tracking.RecordAtDate = Convert.ToString(dt.Rows[0]["RecordAtDate"]);
                tracking.RecordAtTime = Convert.ToString(dt.Rows[0]["RecordAtTime"]);
                tracking.Longitude = Convert.ToString(dt.Rows[0]["Longitude"]);
                tracking.Latitude = Convert.ToString(dt.Rows[0]["Latitude"]);
            }

            return tracking;
        }

        /// <summary>
        /// Location of Vehicle at Date and Time
        /// </summary>
        /// <param name="vehicleMaster"></param>
        /// <param name="date"></param>
        /// <param name="time"></param>
        /// <returns></returns>
        public VehicleTracking GetLocationByVehicle(string Chip_SN, DateTime atDateTime)
        {
            SqlParameter[] parameter = new SqlParameter[3];

            parameter[0] = new SqlParameter("@chip_SN", Chip_SN);
            parameter[1] = new SqlParameter("@atDate", atDateTime.Date);
            parameter[2] = new SqlParameter("@atTime", atDateTime.TimeOfDay);

            var dt = _context.ExecuteQuery("GetLocationAtDateTimeByVehicle", parameter);

            VehicleTracking tracking = null;
            if (dt != null && dt.Rows.Count > 0)
            {
                tracking = new VehicleTracking();
                tracking.RawDataRecived = Convert.ToString(dt.Rows[0]["RawDataRecived"]);
                tracking.VehicleId = Convert.ToInt32(dt.Rows[0]["VehicleId"]);
                tracking.RecordAtDate = Convert.ToString(dt.Rows[0]["RecordAtDate"]);
                tracking.RecordAtTime = Convert.ToString(dt.Rows[0]["RecordAtTime"]);
                tracking.Longitude = Convert.ToString(dt.Rows[0]["Longitude"]);
                tracking.Latitude = Convert.ToString(dt.Rows[0]["Latitude"]);
            }

            return tracking;
        }

        /// <summary>
        /// Get Location in range
        /// </summary>
        /// <param name="vehicleMaster"></param>
        /// <param name="fromDate"></param>
        /// <param name="fromTime"></param>
        /// <param name="toDate"></param>
        /// <param name="toTime"></param>
        /// <returns></returns>
        public List<VehicleTracking> GetLocationByVehicle(string Chip_SN, DateTime fromDateTime, DateTime toDateTime)
        {
            SqlParameter[] parameter = new SqlParameter[5];

            parameter[0] = new SqlParameter("@chip_SN", Chip_SN);
            parameter[1] = new SqlParameter("@fromDate", fromDateTime.Date);
            parameter[2] = new SqlParameter("@fromTime", fromDateTime.TimeOfDay);
            parameter[3] = new SqlParameter("@toDate", toDateTime.Date);
            parameter[4] = new SqlParameter("@toTime", toDateTime.TimeOfDay);

            var dt = _context.ExecuteQuery("GetLocationInDurationByVehicle", parameter);

            List<VehicleTracking> listTracking = new List<VehicleTracking>();

            foreach (DataRow dr in dt.AsEnumerable())
            {
                VehicleTracking tracking = new VehicleTracking();
                tracking.RawDataRecived = Convert.ToString(dt.Rows[0]["RawDataRecived"]);
                tracking.VehicleId = Convert.ToInt32(dt.Rows[0]["VehicleId"]);
                tracking.RecordAtDate = Convert.ToString(dt.Rows[0]["RecordAtDate"]);
                tracking.RecordAtTime = Convert.ToString(dt.Rows[0]["RecordAtTime"]);
                tracking.Longitude = Convert.ToString(dt.Rows[0]["Longitude"]);
                tracking.Latitude = Convert.ToString(dt.Rows[0]["Latitude"]);

                listTracking.Add(tracking);
            }

            return listTracking;
        }

        /// <summary>
        /// Get Vehicle by Apikey and Chip_Sn
        /// </summary>
        /// <param name="apiKey"></param>
        /// <param name="@chip_SN"></param>
        /// <returns></returns>
        public VehicleMaster GetVehicleByKey(string apiKey, string Chip_SN)
        {
            SqlParameter[] parameter = new SqlParameter[2];

            parameter[0] = new SqlParameter("@apiKey", apiKey);
            parameter[1] = new SqlParameter("@chip_SN", Chip_SN);

            var dt = _context.ExecuteQuery("GetVehicleByKey", parameter);

            VehicleMaster vehicle = null;
            if (dt != null && dt.Rows.Count > 0)
            {
                vehicle = new VehicleMaster();
                vehicle.VehicleId = Convert.ToInt32(dt.Rows[0]["VehicleId"]);
                vehicle.API_Key = Convert.ToString(dt.Rows[0]["API_Key"]);
                vehicle.Chip_SN = Convert.ToString(dt.Rows[0]["Chip_SN"]);
                vehicle.ShardMapId = Convert.ToInt32(dt.Rows[0]["ShardMapId"]);
            }

            return vehicle;
        }

        /// <summary>
        /// Get User by Username and Password
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public master_User GetUser(string userName, string password)
        {
            SqlParameter[] parameter = new SqlParameter[2];

            parameter[0] = new SqlParameter("@userName", userName);
            parameter[1] = new SqlParameter("@password", password);


            DataTable dt = _context.ExecuteQuery("GetUser", parameter);

            master_User user = null;
            if (dt != null && dt.Rows.Count > 0)
            {
                user = new master_User();
                user.FullName = Convert.ToString(dt.Rows[0]["FullName"]);
            }

            return user;
        }

        public VehicleMaster GetVehiclByChipSN(string Chip_SN)
        {
            SqlParameter[] parameter = new SqlParameter[1];

            parameter[0] = new SqlParameter("@chip_SN", Chip_SN);

            var dt = _context.ExecuteQuery("GetVehicleByChipSN", parameter);

            VehicleMaster vehicle = null;
            if (dt != null && dt.Rows.Count > 0)
            {
                vehicle = new VehicleMaster();
                vehicle.API_Key = Convert.ToString(dt.Rows[0]["API_Key"]);
                vehicle.Chip_SN = Convert.ToString(dt.Rows[0]["Chip_SN"]);
                vehicle.ShardMapId = Convert.ToInt32(dt.Rows[0]["ShardMapId"]);
            }

            return vehicle;
        }

        bool ITSRepository.RegisterVehicle(VehicleMaster vehicle)
        {
            SqlParameter[] parameter = new SqlParameter[2];

            parameter[0] = new SqlParameter("@apiKey", vehicle.API_Key);
            parameter[1] = new SqlParameter("@chip_SN", vehicle.Chip_SN);

            _context.ExecuteCommand("RegisterVehicleMaster", parameter);

            return true;
        }
    }
}
