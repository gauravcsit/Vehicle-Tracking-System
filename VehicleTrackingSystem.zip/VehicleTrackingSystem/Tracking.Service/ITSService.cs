﻿
using System;
using System.Collections.Generic;
using TrackingSystem.Entities;

namespace TrackingSystem.Services
{
    //Core: Services
    public interface ITSService
    {       
        bool TrackedDataRecieved(string receivedMessage);
               
        VehicleMaster GetVehiclesByChipSN(string chip_SN);

        VehicleTracking GetVehicleCurrentLocation(string chip_SN);

        List<VehicleTracking> GetLocationByVehicle(string chip_SN, DateTime fromDatetime, DateTime toDate);

        master_User GetUser(string username, string password);
    }
}
