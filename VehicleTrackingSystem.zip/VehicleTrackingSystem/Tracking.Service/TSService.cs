﻿using System;
using System.Collections.Generic;
using TrackingSystem.Entities;
using TrackingSystem.Repo;

namespace TrackingSystem.Services
{
    public class TSService : ITSService
    {
        private readonly ITSRepository _repository;

        public TSService(ITSRepository repository)
        {
            _repository = repository;
        }

        public List<VehicleTracking> GetLocationByVehicle(string chip_SN, DateTime fromDateTime, DateTime toDateTime)
        {
            return _repository.GetLocationByVehicle(chip_SN, fromDateTime, toDateTime);
        }

        public master_User GetUser(string username, string password)
        {
            return _repository.GetUser(username, password);
        }

        public VehicleTracking GetVehicleCurrentLocation(string chip_SN)
        {
            return _repository.GetCurrentLocationByVehicle(chip_SN);
        }

        public VehicleMaster GetVehiclesByChipSN(string chip_SN)
        {
            return _repository.GetVehiclByChipSN(chip_SN);
        }

        public bool TrackedDataRecieved(string receivedMessage)
        {
            if (String.IsNullOrEmpty(receivedMessage))
            {
                return false;
            }

            // Decode data Message recieved from device 
            MessageNMEA messageNMEA = MessageDecoder(receivedMessage);

            if (messageNMEA == null)
            {
                return false;
            }
            else
            {
                //Get Registered Vehicle id
                VehicleMaster vehicle = _repository.GetVehicleByKey(messageNMEA.vehicleDetails.API_Key, messageNMEA.vehicleDetails.Chip_SN);

                if (vehicle == null)
                {
                    VehicleMaster vehicleMaster = new VehicleMaster()
                    {
                        API_Key = messageNMEA.vehicleDetails.API_Key,
                        Chip_SN = messageNMEA.vehicleDetails.Chip_SN,

                    };

                    // Register Vehicle
                    _repository.RegisterVehicle(vehicleMaster);
                    // Get Vehicle
                    vehicle = _repository.GetVehiclByChipSN(messageNMEA.vehicleDetails.Chip_SN);
                }

                if (vehicle == null)
                {
                    return false;
                }
                else
                {
                    // Map Entity
                    VehicleTracking vehicleTracking = new VehicleTracking()
                    {
                        VehicleId = vehicle.VehicleId,
                        RawDataRecived = messageNMEA.rawRMC,
                        RecordAtDate = messageNMEA.RMC.Date,
                        RecordAtTime = messageNMEA.RMC.Time,
                        Speed = messageNMEA.RMC.Speed,
                        Latitude = messageNMEA.RMC.Latitude,
                        LatitudeCompassDirection = messageNMEA.RMC.LatitudeCompass,
                        Longitude = messageNMEA.RMC.Longitude,
                        LongitudeCompassDirection = messageNMEA.RMC.LongitudeCompass,

                    };

                    // Record tracking data
                    _repository.RecordVehicleTracking(vehicleTracking, vehicle.ShardMapId);
                    return true;
                }

            }
        }


        private bool IsCheckSumValid(string nmeaSentance)
        {
            try
            {
                if (nmeaSentance != string.Empty && nmeaSentance.Contains("$") && nmeaSentance.Contains("*"))
                {
                    return false;
                }

                //checksum found in string
                string checksumStr = nmeaSentance.Substring(nmeaSentance.IndexOf('*')+1);

                //Start with first Item
                int checksum = Convert.ToByte(nmeaSentance[nmeaSentance.IndexOf('$') + 1]);
                // Loop through all chars to get a checksum
                for (int i = nmeaSentance.IndexOf('$') + 2; i < nmeaSentance.IndexOf('*'); i++)
                {
                    // No. XOR the checksum with this character's value
                    checksum ^= Convert.ToByte(nmeaSentance[i]);
                }

                // Compair checksum formatted as a two-character hexadecimal with checksum found in string
                return (checksum.ToString("X2") == checksumStr);
            }
            catch (Exception)
            {
                return false;
            }
        }

        private MessageNMEA MessageDecoder(string receivedMessage)
        {
            MessageNMEA messageNMEA = null;

            string[] splitMessage = null;
            string[] validCodes = { "GPRMC", "GPKEY" };

            bool flagGPKEY = false;
            bool flagGPRMC = false;

            if (receivedMessage != null && receivedMessage != string.Empty)
            {
                splitMessage = receivedMessage.Split('$');

                messageNMEA = new MessageNMEA();


                foreach (string msg in splitMessage)
                {
                    // int flag
                    foreach (string code in validCodes)
                    {
                        if (msg.Length > 5 && code.Equals(msg.Substring(0, 5)))
                        {
                            string[] gpkey = msg.Split(',');

                            if (code == "GPKEY" && gpkey.Length >= 3 && flagGPKEY == false)
                            {
                                flagGPKEY = true;

                                messageNMEA.vehicleDetails = new VehicleMaster();

                                string type = gpkey[0];

                                messageNMEA.vehicleDetails.API_Key = gpkey[1];
                                messageNMEA.vehicleDetails.Chip_SN = gpkey[2];
                            }
                            else if (code == "GPRMC" && gpkey.Length >= 12 && flagGPRMC == false)
                            {
                                if (!IsCheckSumValid(msg))
                                {
                                    break;
                                }
                                else
                                {
                                    flagGPRMC = true;

                                    messageNMEA.rawRMC = "$" + msg;

                                    messageNMEA.RMC = new TypeRMC();

                                    string type = gpkey[0];
                                    messageNMEA.RMC.Time = gpkey[1];
                                    messageNMEA.RMC.Position = gpkey[2];
                                    messageNMEA.RMC.Latitude = gpkey[3];
                                    messageNMEA.RMC.LatitudeCompass = gpkey[4];
                                    messageNMEA.RMC.Longitude = gpkey[5];
                                    messageNMEA.RMC.LongitudeCompass = gpkey[6];
                                    messageNMEA.RMC.Speed = gpkey[7];
                                    messageNMEA.RMC.Heading = gpkey[8];
                                    messageNMEA.RMC.Date = gpkey[9];
                                    messageNMEA.RMC.MagneticVariation = gpkey[10];
                                    messageNMEA.RMC.MagneticVariationDirection = gpkey[11];
                                }
                            }
                        }
                    }
                }
            }

            // Check have  GPKEY and RMC both. Return null if anyone missing
            if (flagGPKEY && flagGPRMC)
            {
                return messageNMEA;
            }
            else
            {
                return null;
            }
        }

    }
}
