﻿
namespace TrackingSystem.Services
{
    public interface ISettingService
    {
        string GetTSConnectionString();
    }
}
