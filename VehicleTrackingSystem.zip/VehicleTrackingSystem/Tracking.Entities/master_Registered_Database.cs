
namespace TrackingSystem.Entities
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class master_Registered_Database
    {
        [Key]
        public int ShardMapId { get; set; }

        public string TableName { get; set; }

        public int? VehicleCount { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedOn { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ModifiedOn { get; set; }

        public int? CreatedBy { get; set; }

        public int? ModifiedBy { get; set; }

        public bool Active { get; set; }

        public bool IsDeleted { get; set; }
    }
}
