﻿
namespace TrackingSystem.Entities
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class VehicleMaster
    {
        [Key]
        public int VehicleId { get; set; }

        [StringLength(50)]
        public string API_Key { get; set; }

        public int? VehicleRegistrationNumber { get; set; }

        [StringLength(50)]
        public string VehicleName { get; set; }

        [StringLength(50)]
        public string Chip_SN { get; set; }

        public DateTime? RegisteredOn { get; set; }

        public int ShardMapId { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedOn { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ModifiedOn { get; set; }

        public int? CreatedBy { get; set; }

        public int? ModifiedBy { get; set; }

        public bool Active { get; set; }

        public bool IsDeleted { get; set; }
    }
}
