﻿
namespace TrackingSystem.Entities
{
    public class MessageNMEA
    {
        public string rawRMC;
        public VehicleMaster vehicleDetails;
        public TypeRMC RMC;

        public MessageNMEA()
        {
            vehicleDetails = null;
            RMC = null;
        }


    }
}
