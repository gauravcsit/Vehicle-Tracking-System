

namespace TrackingSystem.Entities
{
    using System;

    public class VehicleTracking
    {
        public long Id { get; set; }

        public string RawDataRecived { get; set; }

        public int? VehicleId { get; set; }

        public string RecordAtDate { get; set; }

        public string RecordAtTime { get; set; }

        public string Speed { get; set; }

        public DateTime? CreatedOn { get; set; }

        public int? CreatedBy { get; set; }

        public bool Active { get; set; }

        public bool IsDeleted { get; set; }

        public string Latitude { get; set; }

        public string LatitudeCompassDirection { get; set; }

        public string Longitude { get; set; }

        public string LongitudeCompassDirection { get; set; }
    }
}
