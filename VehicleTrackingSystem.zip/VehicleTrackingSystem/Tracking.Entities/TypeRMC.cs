﻿
namespace TrackingSystem.Entities
{
    public class TypeRMC
    {
        public string Time;
        public string Position;
        public string Latitude;
        public string LatitudeCompass;
        public string Longitude;
        public string LongitudeCompass;
        public string Speed;
        public string Heading;
        public string Date;
        public string MagneticVariation;
        public string MagneticVariationDirection;
    }
}
