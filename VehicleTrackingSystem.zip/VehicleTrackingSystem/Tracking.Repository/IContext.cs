﻿
using System.Data;
using System.Data.SqlClient;

namespace TrackingSystem.Repo
{
    public interface IContext
    {
        void SetConnectionString(string connectionString);

        DataTable ExecuteQuery(string spName, SqlParameter[] parametersy);
        void ExecuteCommand(string spName, SqlParameter[] parameters);
    }
}
