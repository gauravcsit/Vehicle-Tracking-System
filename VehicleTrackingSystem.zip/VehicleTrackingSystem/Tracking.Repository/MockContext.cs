﻿using TrackingSystem.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrackingSystem.Entities;
using System.Data.SqlClient;
using System.Data;

namespace TrackingSystem.Services
{
    public class MockContext : IContext
    {
        private string _connectionString;

        public void SetConnectionString(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void ExecuteCommand(string spName, SqlParameter[] parameters)
        {
            SqlConnection con = null;
            using (con = new SqlConnection(_connectionString))
            using (SqlCommand cmd = new SqlCommand(spName, con))
            {
                try
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    
                    foreach (var item in parameters)
                    {
                        cmd.Parameters.AddWithValue(item.ParameterName,item.Value);
                    }

                    con.Open();
                    int r = cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {

                }
                finally
                {
                    con.Close();
                }
            }

        }

        public DataTable ExecuteQuery(string spName, SqlParameter[] parameters)
        {
            SqlConnection con = null;
            using (con = new SqlConnection(_connectionString))
            using (SqlCommand cmd = new SqlCommand(spName, con))
            {
                try
                {
                    cmd.CommandType = CommandType.StoredProcedure;


                    foreach (var item in parameters)
                    {
                        cmd.Parameters.AddWithValue(item.ParameterName,item.Value);
                    }

                    con.Open();
                    DataTable dt=new DataTable();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);

                    return dt;
                }
                catch (Exception e)
                {
                    return null;
                }
                finally
                {
                    con.Close();

                }
            }
        }
    }
}
