﻿using System;
using System.Collections.Generic;
using System.Linq;
using TrackingSystem.Entities;


namespace TrackingSystem.Repo
{
    //Core: Repository
    public interface ITSRepository
    {
        VehicleTracking GetCurrentLocationByVehicle(string Chip_SN);

        VehicleTracking GetLocationByVehicle(string Chip_SN, DateTime dateTime);

        List<VehicleTracking> GetLocationByVehicle(string Chip_SN, DateTime fromDateTime, DateTime toDateTime);

        VehicleMaster GetVehiclByChipSN(string Chip_SN);

        VehicleMaster GetVehicleByKey(string apiKey, string Chip_SN);

        bool RegisterVehicle(VehicleMaster vehicle);

        bool RecordVehicleTracking(VehicleTracking vehicleTracking, int shardMapId);

        /// <summary>
        /// Get user by username and password 
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        master_User GetUser(string userName, string password);

    }
}
