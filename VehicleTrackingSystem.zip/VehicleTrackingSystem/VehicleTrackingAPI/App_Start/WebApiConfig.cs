﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace VehicleTrackingAPI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{username};{password};{chip_sn};{fromdatetime};{todatetime}",
                defaults: new { username = RouteParameter.Optional, password = RouteParameter.Optional, chip_sn= RouteParameter.Optional, fromdatetime = RouteParameter.Optional, todatetime = RouteParameter.Optional, }
            );

            config.Routes.MapHttpRoute(
                name: "DefaultApi1",
                routeTemplate: "api/{controller}/{username};{password};{chip_sn}",
                defaults: new { username = RouteParameter.Optional, password = RouteParameter.Optional, chip_sn = RouteParameter.Optional }
            );

            config.Routes.MapHttpRoute(
                name: "DefaultApi2",
                routeTemplate: "api/{controller}/{receivedMessage}",
                defaults: new { receivedMessage = RouteParameter.Optional }
            );

            config.Routes.MapHttpRoute(
            name: "NearByPlaces",
            routeTemplate: "api/{controller}/{action}/{username};{password};{chip_sn};{search}",
            defaults: new { username = RouteParameter.Optional, password = RouteParameter.Optional, chip_sn = RouteParameter.Optional, search = RouteParameter.Optional }
            );

            
        }
    }
}
