﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Tracking.Entities;
using TrackingSystem.Entities;
using TrackingSystem.Repo;
using TrackingSystem.Services;

namespace VehicleTrackingAPI.Controllers
{
    public class VehicleTrackingController : ApiController
    {
        [AcceptVerbs("GET", "POST")]
        public string VehicleTracking(string receivedMessage)
        {
            ISettingService settingSvc = new FileSettingService();
            IContext mockContext = new MockContext();
            ITSRepository tsRepository = new TSRepository(settingSvc, mockContext);
            ITSService tsService = new TSService(tsRepository);

            bool result = tsService.TrackedDataRecieved(receivedMessage);

            return "success";
        }

        [AcceptVerbs("GET", "POST")]
        public string CheckCurrentLocationAsync(string username, string password, string chip_sn)
        {
            ISettingService settingSvc = new FileSettingService();
            IContext mockContext = new MockContext();
            ITSRepository tsRepository = new TSRepository(settingSvc, mockContext);
            ITSService tsService = new TSService(tsRepository);

            var user = tsService.GetUser(username, password);

            if (user != null)
            {
                VehicleTracking tracking = tsService.GetVehicleCurrentLocation(chip_sn);
                if (tracking != null)
                {
                    return "Latitude : " + tracking.Latitude + " ; Longitude : " + tracking.Longitude;
                }
                else
                {
                    return "Chip_sn not found";
                }
            }
            else
            {
                return "Invalid Username or password";
            }
        }

        [AcceptVerbs("GET")]
        public string CheckCurrentLocation(string username, string password, string chip_sn, string fromdatetime, string todatetime)
        {
            ISettingService settingSvc = new FileSettingService();
            IContext mockContext = new MockContext();
            ITSRepository tsRepository = new TSRepository(settingSvc, mockContext);
            ITSService tsService = new TSService(tsRepository);

            var user = tsService.GetUser(username, password);

            if (user != null)
            {

                DateTime fromDateTime = DateTime.ParseExact(fromdatetime, "ddMMyy HHmmss", System.Globalization.CultureInfo.InvariantCulture);
                DateTime toDateTime = DateTime.ParseExact(todatetime, "ddMMyy HHmmss", System.Globalization.CultureInfo.InvariantCulture);

                if (fromDateTime == null)
                {
                    return "Invalid FromDatetime";
                }
                else if (toDateTime == null)
                {
                    return "Invalid ToDatetime";
                }
                else
                {
                    List<VehicleTracking> trackings = tsService.GetLocationByVehicle(chip_sn, fromDateTime, toDateTime);

                    string result = "";
                    foreach (VehicleTracking tracking in trackings)
                    {
                        result = result + "Latitude : " + tracking.Latitude + " ; Longitude : " + tracking.Longitude + "\r\n";
                    }

                    if (result != "")
                    {
                        return result;
                    }
                    else
                    {
                        return "Not Found";
                    }
                }
            }
            else
            {
                return "Invalid Username or password";
            }
        }

        [AcceptVerbs("GET")]
        public async System.Threading.Tasks.Task<string> NearByPlaces(string username, string password, string chip_sn, string search)
        {
            ISettingService settingSvc = new FileSettingService();
            IContext mockContext = new MockContext();
            ITSRepository tsRepository = new TSRepository(settingSvc, mockContext);
            ITSService tsService = new TSService(tsRepository);

            var user = tsService.GetUser(username, password);

            if (user != null)
            {
                VehicleTracking tracking = tsService.GetVehicleCurrentLocation(chip_sn);
                if (tracking != null)
                {
                    var result = await NearbyLocationsAsync(tracking.Latitude, tracking.Longitude, search);
                    return result;
                }                
            }    
            return null;
        }

        public async System.Threading.Tasks.Task<string> NearbyLocationsAsync(string latitude, string longitude, string search)
        {
            string googleApiKey = "AIzaSyAV-fwe7INB4tzyr16xCBDpl06f2fqzQDQ";
            using (var client = new HttpClient())
            {
                string requestUpl = string.Format("https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input={0}&inputtype=textquery&fields=name&locationbias=circle:{1},{2}&key={3}", search, latitude, longitude, googleApiKey);

                var response = await client.GetStringAsync(requestUpl);
                return response;
            }
        }
    }

}